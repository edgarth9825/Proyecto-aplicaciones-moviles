//
//  ServiciosViewController.swift
//  Constructora Spitia
//
//  Created by Abi Torres on 14/04/21.
//

import UIKit

class ServiciosViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Servicios de la empresa"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
