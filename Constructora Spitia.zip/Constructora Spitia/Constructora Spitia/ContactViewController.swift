//
//  ContactViewController.swift
//  Constructora Spitia
//
//  Created by Abi Torres on 14/04/21.
//

import UIKit


class ContactViewController: UIViewController {

    
    @IBAction func btnAction(_ sender: UIButton) {
        guard let numberString = sender.titleLabel?.text, let url = URL (string:"telprompt://\(numberString)") else {
            return
        }
        
        UIApplication.shared.open(url)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Contácto"
        // Do any additional setup after loading the view.
    }
    
}
